package ex2;
public class Main {
    public static void main(String[] args){
        Aluno a1 = new Aluno(123456, 19, "Pedro", 10, 8);
        a1.dadosAluno();
    }
}
